/*
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package sessions_bug;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.*;
import java.util.Vector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DummyCart {

    final Vector v = new Vector();
    String submit = null;
    String item = null;
    ExecutorService executor = Executors.newCachedThreadPool();

    private synchronized void addItem(String name) {
        try {
            Thread.sleep(300);
        } catch (InterruptedException ex) {
            Logger.getLogger(DummyCart.class.getName()).log(Level.SEVERE, null, ex);
        }
        synchronized (v) {
            v.addElement(name);
            Thread.dumpStack();
        }
    }

    private void removeItem(String name) {
        v.removeElement(name);
    }

    public void setItem(String name) {
        item = name;
    }

    public void setSubmit(String s) {
        submit = s;
    }

    public String[] getItems() {
        String[] s = new String[v.size()];
        v.copyInto(s);
        return s;
    }

    public void processRequest(HttpServletRequest request) {
        // null value for submit - user hit enter instead of clicking on
        // "add" or "remove"
        if (submit == null) {
            addItem(item);
        }
        if (submit.equals("add")) {
            executor.submit(new Runnable() {

                public void run() {
                    addItem(item);
                }
            });
            synchronized (v) {
                try {
                    Thread.sleep(300);
                } catch (InterruptedException ex) {
                    Logger.getLogger(DummyCart.class.getName()).log(Level.SEVERE, null, ex);
                }
                synchronized (this) {
                    System.out.println(v.size());
                }
            }
        } else if (submit.equals("remove")) {
            removeItem(item);
        }

        // reset at the end of the request
        reset();
    }

    // reset
    private void reset() {
        submit = null;
        item = null;
    }
}
